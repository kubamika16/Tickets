const navLinks = document.getElementById("navLinks");
console.log(navLinks);

const showMenu = () => {
  navLinks.style.right = "0";
};

const hideMenu = () => {
  navLinks.style.right = "-200px";
};
